<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Mis System</title>
<link rel="stylesheet" type="text/css" href="../styling.css">
</head>

<body>
<h1 class="text-center"><span class="one">W</span>elcome to</h1>
<h1 class="text-center"><span class="one">C</span>OVID-19 <span class="one">M</span>IS System</h1>
<h3 class="text-center">Lab Technician</h3>
<div class="text-center">
<a href="home.php"><button class="main-btn">Home</button></a>
<a href="test_info.php"><button class="main-btn">Test Information</button></a>
<a href="logout.php"><button class="main-btn">Logout</button></a>
</div>
</body>
</html>