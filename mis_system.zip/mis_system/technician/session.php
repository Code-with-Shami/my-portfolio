<?php
include_once "../connection.php";
if(!isset($_SESSION['technician'])){
	header('location:../index.php');
}
$sql="select * from technician where username='".$_SESSION['technician']."'";
$result=mysqli_query($con,$sql);
$technician=mysqli_fetch_array($result);
?>