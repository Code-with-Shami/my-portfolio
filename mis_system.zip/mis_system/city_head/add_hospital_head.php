<?php
include_once "session.php";
if(isset($_POST['submit']))
{
	$name=$_POST['name'];
	$hospital=$_POST['hospital'];
	$email=$_POST['email'];
	$username=$_POST['username'];
	$password=$_POST['password'];
	$contact=$_POST['contact'];
	$address=$_POST['address'];
	$sql="select * from hospital_head where hospital_id='$hospital'";
	$result=mysqli_query($con,$sql);
	if(mysqli_num_rows($result)>0){
		echo "<script>alert('Hospital head already added')</script>";
	}
	else{
		$sql="insert into hospital_head values('','$hospital','$name','$email','$username','$password','$contact','$address')";
		$result=mysqli_query($con,$sql);
		if($result)
		{
			echo "<script>alert('Hospital head information added into database successfully')</script>";
	
		}
		else
		{
			echo "<script>alert('Sorry')</script>";
		}
	}
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Mis System</title>
<link rel="stylesheet" type="text/css" href="../styling.css">
</head>

<body>
<form method="post">
  <fieldset>
    <legend>Enter Hospital Head Information:</legend>
    Name:<br>
    <input type="text" name="name" placeholder="Enter name" required class="input">
    Hospital:<br>
    <select name="hospital" required class="input">
    <option value="">- Select -</option>
    <?php
    $sql="select * from hospital where city_id='".$city_head['city_id']."'";
    $result=mysqli_query($con,$sql);
    while($row=mysqli_fetch_array($result)){
    ?>
    <option value="<?php echo $row['id'];?>"><?php echo $row['hospital_name'];?></option>
    <?php } ?>
    </select>
    Email:<br>
    <input type="email" name="email" placeholder="Enter email" required class="input">
    Username:<br>
    <input type="text" name="username" placeholder="Enter username" required class="input">
    Password:<br>
    <input type="password" name="password" placeholder="Enter password" required class="input">
    Contact:<br>
    <input type="text" name="contact" placeholder="Enter contact" required class="input">
    <label>Address</label>
    <input type="text" name="address" placeholder="Enter address" required class="input">
    <input type="submit" name="submit" class="login-btn" value="Submit"><br>
    <a href="home.php" class="clr-btn">Back to Home</a>
  </fieldset>
</form>
</body>
</html>