<?php
include_once "session.php";
if(isset($_POST['submit'])){
	$name=$_POST['name'];
	$hospital=$_POST['hospital'];
	$email=$_POST['email'];
	$username=$_POST['username'];
	$password=$_POST['password'];
	$contact=$_POST['contact'];
	$speciality=$_POST['speciality'];
	$address=$_POST['address'];
	$sql="insert into doctor values('','$name','$email','$username','$password','$contact','$speciality','$address')";
	$result=mysqli_query($con,$sql);
	$doctor_id=mysqli_insert_id($con);
	for($i=0;$i<count($hospital);$i++){
		$sql="insert into doctor_work values('','$doctor_id','".$hospital[$i]."')";
		$result=mysqli_query($con,$sql);
	}
	if($result){
		echo "<script>alert('Doctor information store on the database')</script>";
	}
	else{
		echo "<script>alert('something went wrong')</script>";
	}
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Mis System</title>
<link rel="stylesheet" type="text/css" href="../styling.css">
</head>

<body>
<form method="post">
  <fieldset>
    <legend>Enter Doctor Information:</legend>
    Name:<br>
    <input type="text" name="name" placeholder="Enter name" required class="input">
    Hospital:<br>
    <select name="hospital[]" multiple required class="input">
    <option value="">- Select -</option>
    <?php
    $sql="select * from hospital where city_id='".$city_head['city_id']."'";
    $result=mysqli_query($con,$sql);
    while($row=mysqli_fetch_array($result)){
    ?>
    <option value="<?php echo $row['id'];?>"><?php echo $row['hospital_name'];?></option>
    <?php } ?>
    </select>
    Email:<br>
    <input type="email" name="email" placeholder="Enter email" required class="input">
    Username:<br>
    <input type="text" name="username" placeholder="Enter username" required class="input">
    Password:<br>
    <input type="password" name="password" placeholder="Enter password" required class="input">
    Contact:<br>
    <input type="text" name="contact" placeholder="Enter contact" required class="input">
    Speciality:<br>
	<input type="text" name="speciality" required placeholder="Enter speciality" class="input">
    <label>Address</label>
    <input type="text" name="address" placeholder="Enter address" required class="input">
    <input type="submit" name="submit" class="login-btn" value="Submit"><br>
    <a href="home.php" class="clr-btn">Back to Home</a>
  </fieldset>
</form>
</body>
</html>