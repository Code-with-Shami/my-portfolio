<?php
include_once "session.php";
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Mis System</title>
<link rel="stylesheet" type="text/css" href="../styling.css">
</head>

<body>
<h3 class="text-center">View Lab Technician Information</h3>
<div class="text-center">
<a href="add_technician.php">Add New</a>
</div>
<table border="1">
<tr>
<th>Sr. No</th>
<th>Hospital Name</th>
<th>Name</th>
<th>Email</th>
<th>Username</th>
<th>Contact</th>
<th>Address</th>
<th></th>
<?php
$i=1;
$sql="select technician.id, hospital_name,  name, email, username, contact, technician.address from technician_work INNER JOIN technician on technician.id=technician_work.technician_id INNER JOIN hospital on hospital.id=technician_work.hospital_id where hospital.city_id='".$city_head['city_id']."'";
$result=mysqli_query($con,$sql);
while($row=mysqli_fetch_array($result)){
?>
<tr>
<td><?php echo $i++;;?></td>
<td><?php echo $row['hospital_name'];?></td>
<td><?php echo $row['name'];?></td>
<td><?php echo $row['email'];?></td>
<td><?php echo $row['username'];?></td>
<td><?php echo $row['contact'];?></td>
<td><?php echo $row['address'];?></td>
<td>
<a href="delete_technician.php?id=<?php echo $row['id'];?>">Delete</a>
</td>
</tr>
<?php
 } ?>
</table>
<div class="text-center">
<a href="home.php">Back to Home</a>
</div>
</body>
</html>