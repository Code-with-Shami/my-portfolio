<?php
include_once "../connection.php";
if(!isset($_SESSION['city_head'])){
	header('location:../index.php');
}
$sql="select * from city_head where username='".$_SESSION['city_head']."'";
$result=mysqli_query($con,$sql);
$city_head=mysqli_fetch_array($result);
?>