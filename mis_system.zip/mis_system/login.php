<?php
if(isset($_POST['login'])){
	include_once "connection.php";
	$username=$_POST['username'];
	$password=$_POST['password'];
	$role=$_POST['role'];
	if($role=='receptionist'){
		$sql="select * from receptionist where username='$username' AND password='$password'";
		$result=mysqli_query($con,$sql);
		$row=mysqli_fetch_array($result);
		if($row){
			$_SESSION['receptionist']=$username;
			header('location:receptionist/home.php');
		}
		else{
			echo "<script>alert('invalid username or password')</script>";
		}
	}
	else if($role=='technician'){
		$sql="select * from technician where username='$username' AND password='$password'";
		$result=mysqli_query($con,$sql);
		$row=mysqli_fetch_array($result);
		if($row){
			$_SESSION['technician']=$username;
			header('location:technician/home.php');
		}
		else{
			echo "<script>alert('invalid username or password')</script>";
		}
	}
	else if($role=='doctor'){
		$sql="select * from doctor where username='$username' AND password='$password'";
		$result=mysqli_query($con,$sql);
		$row=mysqli_fetch_array($result);
		if($row){
			$_SESSION['doctor']=$username;
			header('location:doctor/home.php');
		}

		else{
			echo "<script>alert('invalid username or password')</script>";
		}
	}
       else if($role=='hospital_head'){
		$sql="select * from hospital_head where username='$username' AND password='$password'";
		$result=mysqli_query($con,$sql);
		$row=mysqli_fetch_array($result);
		if($row){
			$_SESSION['hospital_head']=$username;
			header('location:hospital_head/home.php');
		}

		else{
			echo "<script>alert('invalid username or password')</script>";
		}
	}
         else if($role=='city_head'){
		$sql="select * from city_head where username='$username' AND password='$password'";
		$result=mysqli_query($con,$sql);
		$row=mysqli_fetch_array($result);
		if($row){
			$_SESSION['city_head']=$username;
			header('location:city_head/home.php');
		}

		else{
			echo "<script>alert('invalid username or password')</script>";
		}
        }
          else if($role=='country_head'){
		$sql="select * from country_head where username='$username' AND password='$password'";
		$result=mysqli_query($con,$sql);
		$row=mysqli_fetch_array($result);
		if($row){
			$_SESSION['country_head']=$username;
			header('location:country_head/home.php');
		}

		else{
			echo "<script>alert('invalid username or password')</script>";
		}
        }
          else if($role=='admin'){
		$sql="select * from admin where username='$username' AND password='$password'";
		$result=mysqli_query($con,$sql);
		$row=mysqli_fetch_array($result);
		if($row){
			$_SESSION['admin']=$username;
			header('location:admin/home.php');
		}

		else{
			echo "<script>alert('invalid username or password')</script>";
		}
        }
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Mis System</title>
<link rel="stylesheet" type="text/css" href="styling.css">
</head>

<body>
<form method="post">
  <fieldset>
    <legend>Login:</legend>
    Username:<br>
    <input type="text" name="username" required placeholder="Enter username..." class="input">
    Password:
    <input type="password" name="password" required placeholder="Enter password..." class="input">
    Role:
    <select name="role" required class="input">
    <option value="">- Select -</option>
    <option value="receptionist">Receptionist</option>
    <option value="technician">Lab Technician</option>
     <option value="doctor">Doctor</option>
     <option value="hospital_head">Hospital Head</option>
    <option value="city_head">City Head</option>
    <option value="country_head">Country Head</option>
   <option value="admin">Admin</option>
    </select>
    <input type="submit" name="login" class="login-btn" value="Submit"><br>
    <a href="index.php">Back to Home</a>
  </fieldset>
</form>
</body>
</html>