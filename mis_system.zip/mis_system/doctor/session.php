<?php
include_once "../connection.php";
if(!isset($_SESSION['doctor'])){
	header('location:../index.php');
}
$sql="select * from doctor where username='".$_SESSION['doctor']."'";
$result=mysqli_query($con,$sql);
$doctor=mysqli_fetch_array($result);
?>