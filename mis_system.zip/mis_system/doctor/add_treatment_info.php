<?php
include_once "session.php";
if(isset($_POST['submit'])){
	$name=$_POST['name'];
	$hospital=$_POST['hospital'];
	$age=$_POST['age'];
	$gender=$_POST['gender'];
	$address=$_POST['address'];
	$description=$_POST['description'];
	$date=date('Y-m-d');
	$sql="insert into treatment_info values('','".$doctor['id']."','$hospital','$name','$age','$gender','$address','$description','$date')";
	$result=mysqli_query($con,$sql);
	if($result){
		echo "<script>alert('Patient treatment information store on the database')</script>";
	}
	else{
		echo "<script>alert('soemthing went wrong')</script>";
	}
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Mis System</title>
<link rel="stylesheet" type="text/css" href="../styling.css">
</head>

<body>
<form method="post">
  <fieldset>
    <legend>Enter Patient Treatment Information:</legend>
    Patient Name:<br>
    <input type="text" name="name" required placeholder="Enter name..." class="input">
    Hospital:
    <select name="hospital" required class="input">
    <option value="">- Select -</option>
	<?php
    $sql="select hospital_name, hospital.id from doctor_work INNER JOIN hospital on hospital.id=doctor_work.hospital_id INNER JOIN doctor on doctor.id=doctor_work.doctor_id where doctor.id='".$doctor['id']."'";
    $result=mysqli_query($con,$sql);
    while($row=mysqli_fetch_array($result)){
    ?>
    <option value="<?php echo $row['id'];?>"><?php echo $row['hospital_name'];?></option>
    <?php } ?>
    </select>
    Age:
    <input type="number" name="age" required placeholder="Enter age..." class="input">
    Address:
    <input type="text" name="address" required placeholder="Enter address..." class="input">
    Gender:
    <select name="gender" required class="input">
    <option value="">- Select -</option>
    <option value="Male">Male</option>
    <option value="Female">Female</option>
    </select>
    Treatment Description:
    <textarea name="description" required placeholder="Enter Treatment Description..." class="input-one" rows="7"></textarea>
    <input type="submit" name="submit" class="login-btn" value="Submit"><br>
    <a href="home.php"> back to Home</a>
  </fieldset>
</form>
</body>
</html>