<?php
include_once "session.php";
$id=$_REQUEST['id'];
if(isset($_POST['submit'])){
	$date=$_POST['date'];
	$sql="update admit_patient set discharge_date='$date', status='1' where id='$id'";
	$result=mysqli_query($con,$sql);
	if($result){
		echo "<script>alert('Discharge patient information store on the database')</script>";
	}
	else{
		echo "<script>alert('soemthing went wrong')</script>";
	}
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Mis System</title>
<link rel="stylesheet" type="text/css" href="../styling.css">
</head>

<body>
<form method="post">
  <fieldset>
    <legend>Enter Discharge Patient Information:</legend>
    Discharge Date:
    <input type="datetime-local" name="date" required class="input">
    <input type="submit" name="submit" class="login-btn" value="Submit"><br>
    <a href="home.php">Back to Home</a>
  </fieldset>
</form>
</body>
</html>