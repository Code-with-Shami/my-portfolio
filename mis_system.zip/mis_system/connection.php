<?php
$host="localhost";
$username="root";
$password="";
$db_name="mis_system";
$con=mysqli_connect($host,$username,$password,$db_name);
session_start();
?>