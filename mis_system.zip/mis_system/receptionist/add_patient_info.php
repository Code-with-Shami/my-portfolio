<?php
include_once "session.php";
if(isset($_POST['submit'])){
	$name=$_POST['name'];
	$age=$_POST['age'];
	$gender=$_POST['gender'];
	$cnic=$_POST['cnic'];
	$contact=$_POST['contact'];
	$address=$_POST['address'];
	$date=date('Y-m-d');
	$sql="insert into patient_info values('','".$receptionist['hospital_id']."','$name','$age','$gender','$cnic','$contact','$address','$date')";
	$result=mysqli_query($con,$sql);
	if($result){
		echo "<script>alert('Patient information store on the database')</script>";
	}
	else{
		echo "<script>alert('soemthing went wrong')</script>";
	}
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Mis System</title>
<link rel="stylesheet" type="text/css" href="../styling.css">
</head>

<body>
<form method="post">
  <fieldset>
    <legend>Enter Patient Information:</legend>
    Patient Name:<br>
    <input type="text" name="name" required placeholder="Enter name..." class="input">
    Age:
    <input type="number" name="age" required placeholder="Enter age..." class="input">
    Address:
    <input type="text" name="address" required placeholder="Enter address..." class="input">
    CNIC:
    <input type="text" name="cnic" required placeholder="Enter CNIC..." class="input">
    Contact:
    <input type="number" name="contact" required placeholder="Enter contact..." class="input">
    Gender:
    <select name="gender" required class="input">
    <option value="">- Select -</option>
    <option value="Male">Male</option>
    <option value="Female">Female</option>
    </select>
    <input type="submit" name="submit" class="login-btn" value="Submit"><br>
    <a href="home.php">Back to Home</a>
  </fieldset>
</form>
</body>
</html>