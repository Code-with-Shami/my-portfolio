<?php
include_once "../connection.php";
if(!isset($_SESSION['receptionist'])){
	header('location:../index.php');
}
$sql="select * from receptionist where username='".$_SESSION['receptionist']."'";
$result=mysqli_query($con,$sql);
$receptionist=mysqli_fetch_array($result);
?>