<?php
include_once "../connection.php";
if(!isset($_SESSION['hospital_head'])){
	header('location:../index.php');
}
$sql="select * from hospital_head where username='".$_SESSION['hospital_head']."'";
$result=mysqli_query($con,$sql);
$hospital_head=mysqli_fetch_array($result);
?>