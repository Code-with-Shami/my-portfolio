<?php
include_once "session.php";
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Mis System</title>
<link rel="stylesheet" type="text/css" href="../styling.css">
</head>

<body>
<h3 class="text-center">View Patient Treatment Information</h3>
<table border="1">
<tr>
<th>Sr. No</th>
<th>Patient Name</th>
<th>Age</th>
<th>Gender</th>
<th>Address</th>
<th>Date</th>
<th>Description</th>
<?php
$i=1;
$sql="select * from treatment_info where hospital_id='".$hospital_head['hospital_id']."'";
$result=mysqli_query($con,$sql);
while($row=mysqli_fetch_array($result)){
?>
<tr>
<td><?php echo $i++;;?></td>
<td><?php echo $row['name'];?></td>
<td><?php echo $row['age'];?></td>
<td><?php echo $row['gender'];?></td>
<td><?php echo $row['address'];?></td>
<td><?php echo $row['date'];?></td>
<td><?php echo $row['description'];?></td>
</tr>
<?php
 } ?>
</table>
<div class="text-center">
<a href="home.php">Back to Home</a>
</div>
</body>
</html>