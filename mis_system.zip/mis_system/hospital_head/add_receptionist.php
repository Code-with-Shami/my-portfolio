<?php
include_once "session.php";
if(isset($_POST['submit'])){
	$name=$_POST['name'];
	$email=$_POST['email'];
	$username=$_POST['username'];
	$password=$_POST['password'];
	$contact=$_POST['contact'];
	$address=$_POST['address'];
	$sql="insert into receptionist values('','".$hospital_head['hospital_id']."','$name','$email','$username','$password','$contact','$address')";
	$result=mysqli_query($con,$sql);
	if($result){
		echo "<script>alert('Receptionist information store on the database')</script>";
	}
	else{
		echo "<script>alert('something went wrong')</script>";
	}
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Mis System</title>
<link rel="stylesheet" type="text/css" href="../styling.css">
</head>

<body>
<form method="post">
  <fieldset>
    <legend>Enter Receptionist Information:</legend>
    Name:<br>
    <input type="text" name="name" placeholder="Enter name" required class="input">
    Email:<br>
    <input type="email" name="email" placeholder="Enter email" required class="input">
    Username:<br>
    <input type="text" name="username" placeholder="Enter username" required class="input">
    Password:<br>
    <input type="password" name="password" placeholder="Enter password" required class="input">
    Contact:<br>
    <input type="text" name="contact" placeholder="Enter contact" required class="input">
    <label>Address</label>
    <input type="text" name="address" placeholder="Enter address" required class="input">
    <input type="submit" name="submit" class="login-btn" value="Submit"><br>
    <a href="home.php" class="clr-btn">Back to Home</a>
  </fieldset>
</form>
</body>
</html>