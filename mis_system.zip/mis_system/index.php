<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Mis System</title>
<link rel="stylesheet" type="text/css" href="styling.css">
</head>

<body>
<h1 class="text-center"><span class="one">W</span>elcome to</h1>
<h1 class="text-center"><span class="one">C</span>OVID-19 <span class="one">M</span>IS System</h1>
<div class="text-center">
<a href="login.php"><button class="btn-one">Login</button></a>
</div>
</body>
</html>