<?php
include_once "../connection.php";
if(!isset($_SESSION['country_head'])){
	header('location:../index.php');
}
$sql="select * from country_head where username='".$_SESSION['country_head']."'";
$result=mysqli_query($con,$sql);
$country_head=mysqli_fetch_array($result);
?>