<?php
include_once "session.php";
if(isset($_POST['submit'])){
	$hospital_name=$_POST['hospital_name'];
	$city=$_POST['city'];
	$address=$_POST['address'];
	$sql="insert into hospital values('','$city','$hospital_name','$address')";
	$result=mysqli_query($con,$sql);
	if($result){
		echo "<script>alert('Hospital information store on the database')</script>";
	}
	else{
		echo "<script>alert('something went wrong')</script>";
	}
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Mis System</title>
<link rel="stylesheet" type="text/css" href="../styling.css">
</head>

<body>
<form method="post">
  <fieldset>
    <legend>Enter City Information:</legend>
    Hospital Name:<br>
    <input type="text" name="hospital_name" placeholder="Enter hospital name" class="input" required>
    City Name:<br>
    <select name="city" class="input" required>
    <option value="">- Select -</option>
    <?php
    $sql="select * from city";
    $result=mysqli_query($con,$sql);
    while($row=mysqli_fetch_array($result)){
    ?>
    <option value="<?php echo $row['id'];?>"><?php echo $row['city_name'];?></option>
    <?php } ?>
    </select>
    Address:<br>
    <input type="text" name="address" placeholder="Enter hospital address" class="input" required>
    <input type="submit" name="submit" class="login-btn" value="Submit"><br>
    <a href="home.php" class="clr-btn">Back to Home</a>
  </fieldset>
</form>
</body>
</html>