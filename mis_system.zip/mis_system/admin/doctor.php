<?php
include_once "session.php";
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Mis System</title>
<link rel="stylesheet" type="text/css" href="../styling.css">
</head>

<body>
<h3 class="text-center">View Doctor Information</h3>
<div class="text-center">
<a href="add_doctor.php">Add New</a>
</div>
<table border="1">
<tr>
<th>Sr. No</th>
<th>Name</th>
<th>Email</th>
<th>Username</th>
<th>Contact</th>
<th>Speciality</th>
<th>Address</th>
<th></th>
<?php
$i=1;
$sql="select * from doctor";
$result=mysqli_query($con,$sql);
while($row=mysqli_fetch_array($result)){
?>
<tr>
<td><?php echo $i++;;?></td>
<td><?php echo $row['name'];?></td>
<td><?php echo $row['email'];?></td>
<td><?php echo $row['username'];?></td>
<td><?php echo $row['contact'];?></td>
<td><?php echo $row['speciality'];?></td>
<td><?php echo $row['address'];?></td>
<td>
<a href="delete_doctor.php?id=<?php echo $row['id'];?>">Delete</a>
</td>
</tr>
<?php
 } ?>
</table>
<div class="text-center">
<a href="home.php">Back to Home</a>
</div>
</body>
</html>