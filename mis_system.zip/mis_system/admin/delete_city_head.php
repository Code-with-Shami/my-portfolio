<?php
include_once "session.php";
$id=$_REQUEST['id'];
$sql="delete from city_head where id='$id'";
$result=mysqli_query($con,$sql);
if($result){
		echo "<script>window.location.href='city_head.php'
		alert('City head delete successfully')</script>";	
	}
	else{
		
		echo "<script>alert('Sorry')</script>";
	}
?>
