<?php
include_once "session.php";
if(isset($_POST['submit'])){
	$name=$_POST['name'];
	$sql="insert into city values('','$name')";
	$result=mysqli_query($con,$sql);
	if($result){
		echo "<script>alert('City information store on the database')</script>";
	}
	else{
		echo "<script>alert('something went wrong')</script>";
	}
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Mis System</title>
<link rel="stylesheet" type="text/css" href="../styling.css">
</head>

<body>
<form method="post">
  <fieldset>
    <legend>Enter City Information:</legend>
    City Name:<br>
    <input type="text" name="name" required placeholder="Enter city name..." class="input">
    <input type="submit" name="submit" class="login-btn" value="Submit"><br>
    <a href="home.php" class="clr-btn">Back to Home</a>
  </fieldset>
</form>
</body>
</html>