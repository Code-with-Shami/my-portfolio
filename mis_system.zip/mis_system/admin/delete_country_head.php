<?php
include_once "session.php";
$id=$_REQUEST['id'];
$sql="delete from country_head where id='$id'";
$result=mysqli_query($con,$sql);
if($result){
		echo "<script>window.location.href='country_head.php'
		alert('Country head delete successfully')</script>";	
	}
	else{
		
		echo "<script>alert('Sorry')</script>";
	}
?>
