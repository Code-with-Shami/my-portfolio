<?php
include_once "session.php";
$id=$_REQUEST['id'];
$sql="delete from patient_info where hospital_id='$id'";
$result=mysqli_query($con,$sql);
$sql="delete from receptionist where hospital_id='$id'";
$result=mysqli_query($con,$sql);

$sql="delete from covid_test_info where hospital_id='$id'";
$result=mysqli_query($con,$sql);
$sql="delete from technician_work where hospital_id='$id'";
$result=mysqli_query($con,$sql);

$sql="delete from admit_patient where hospital_id='$id'";
$result=mysqli_query($con,$sql);
$sql="delete from treatment_info where hospital_id='$id'";
$result=mysqli_query($con,$sql);
$sql="delete from doctor_work where hospital_id='$id'";
$result=mysqli_query($con,$sql);

$sql="delete from hospital_head where hospital_id='$id'";
$result=mysqli_query($con,$sql);
$sql="delete from hospital where id='$id'";
$result=mysqli_query($con,$sql);
if($result){
		echo "<script>window.location.href='hospital.php'
		alert('Hospital delete successfully')</script>";	
	}
	else{
		echo "<script>window.location.href='hospital.php'
		alert('Sorry')</script>";
		
	}
?>
