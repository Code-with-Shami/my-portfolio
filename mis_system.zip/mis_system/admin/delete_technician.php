<?php
include_once "session.php";
$id=$_REQUEST['id'];
$sql="delete from technician_work where technician_id='$id'";
$result=mysqli_query($con,$sql);
$sql="delete from technician where id='$id'";
$result=mysqli_query($con,$sql);
if($result){
		echo "<script>window.location.href='technician.php'
		alert('Lab technician delete successfully')</script>";	
	}
	else{
		
		echo "<script>alert('Sorry')</script>";
	}
?>
