<?php
include_once "session.php";
$id=$_REQUEST['id'];
$sql="delete from treatment_info where doctor_id='$id'";
$result=mysqli_query($con,$sql);
$sql="delete from admit_patient where doctor_id='$id'";
$result=mysqli_query($con,$sql);
$sql="delete from doctor where id='$id'";
$result=mysqli_query($con,$sql);
if($result){
		echo "<script>window.location.href='doctor.php'
		alert('Doctor delete successfully')</script>";	
	}
	else{
		
		echo "<script>alert('Sorry')</script>";
	}
?>
