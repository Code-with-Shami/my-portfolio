<?php
include_once "session.php";
$id=$_REQUEST['id'];
$sql="delete from hospital_head where id='$id'";
$result=mysqli_query($con,$sql);
if($result){
		echo "<script>window.location.href='hospital_head.php'
		alert('Hospital head delete successfully')</script>";	
	}
	else{
		
		echo "<script>alert('Sorry')</script>";
	}
?>
