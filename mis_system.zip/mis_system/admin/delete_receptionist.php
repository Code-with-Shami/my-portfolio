<?php
include_once "session.php";
$id=$_REQUEST['id'];
$sql="delete from receptionist where id='$id'";
$result=mysqli_query($con,$sql);
if($result){
		echo "<script>window.location.href='receptionist.php'
		alert('Receptionist delete successfully')</script>";	
	}
	else{
		
		echo "<script>alert('Sorry')</script>";
	}
?>
