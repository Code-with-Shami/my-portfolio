<?php
include_once "session.php";
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Mis System</title>
<link rel="stylesheet" type="text/css" href="../styling.css">
</head>

<body>
<h3 class="text-center">View Patient Information</h3>
<div class="text-center">
<a href="add_patient_info.php">Add New</a>
</div>
<table border="1">
<tr>
<th>Sr. No</th>
<th>Name</th>
<th>Age</th>
<th>Gender</th>
<th>CNIC</th>
<th>Contact</th>
<th>Address</th>
<th>Date</th>
<?php
$i=1;
$sql="select * from patient_info";
$result=mysqli_query($con,$sql);
while($row=mysqli_fetch_array($result)){
?>
<tr>
<td><?php echo $i++;;?></td>
<td><?php echo $row['name'];?></td>
<td><?php echo $row['age'];?></td>
<td><?php echo $row['gender'];?></td>
<td><?php echo $row['cnic'];?></td>
<td><?php echo $row['contact'];?></td>
<td><?php echo $row['address'];?></td>
<td><?php echo $row['date'];?></td>
</tr>
<?php
 } ?>
</table>
<div class="text-center">
<a href="home.php">Back to Home</a>
</div>
</body>
</html>