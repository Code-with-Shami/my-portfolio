-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 29, 2022 at 05:46 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.3.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mis_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` varchar(80) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `username`, `password`) VALUES
(1, 'Admin', 'admin123', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `admit_patient`
--

CREATE TABLE `admit_patient` (
  `id` int(11) NOT NULL,
  `doctor_id` int(11) NOT NULL,
  `hospital_id` int(11) NOT NULL,
  `name` varchar(80) NOT NULL,
  `age` int(11) NOT NULL,
  `gender` varchar(30) NOT NULL,
  `cnic` varchar(30) NOT NULL,
  `contact` varchar(30) NOT NULL,
  `address` varchar(80) NOT NULL,
  `admit_date` datetime NOT NULL,
  `discharge_date` datetime NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admit_patient`
--

INSERT INTO `admit_patient` (`id`, `doctor_id`, `hospital_id`, `name`, `age`, `gender`, `cnic`, `contact`, `address`, `admit_date`, `discharge_date`, `status`) VALUES
(1, 3, 2, 'Muhammad Yasir', 26, 'Male', '3820145679875', '03435698745', 'Lahore', '2022-02-11 08:30:00', '2022-02-11 06:00:00', 1),
(2, 3, 3, 'Muhammad Waqas', 29, 'Male', '3830498948931', '034378776889', 'Johar Town Lahore', '2022-02-13 12:10:00', '2022-06-13 11:41:00', 1),
(3, 3, 3, 'Zaheer Babar', 26, 'Male', '8130876949948', '030087687989', 'Lahore', '2022-06-17 10:50:00', '2022-06-18 10:57:00', 1),
(4, 3, 3, 'Muhammad Liaqat', 46, 'Male', '86839309901', '945902790', 'abc', '2022-06-29 18:40:00', '2022-06-29 18:43:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `city`
--

CREATE TABLE `city` (
  `id` int(11) NOT NULL,
  `city_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `city`
--

INSERT INTO `city` (`id`, `city_name`) VALUES
(1, 'Lahore'),
(3, 'Islamabad'),
(4, 'Karachi'),
(5, 'Faisalabad '),
(6, 'Multan'),
(7, 'Peshawar');

-- --------------------------------------------------------

--
-- Table structure for table `city_head`
--

CREATE TABLE `city_head` (
  `id` int(11) NOT NULL,
  `city_id` int(11) NOT NULL,
  `name` varchar(80) NOT NULL,
  `email` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `contact` varchar(50) NOT NULL,
  `address` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `city_head`
--

INSERT INTO `city_head` (`id`, `city_id`, `name`, `email`, `username`, `password`, `contact`, `address`) VALUES
(1, 1, 'Hassan Abbas', 'hassan@gmail.com', 'hassan124', '12345', '03002154789', 'ABC');

-- --------------------------------------------------------

--
-- Table structure for table `country_head`
--

CREATE TABLE `country_head` (
  `id` int(11) NOT NULL,
  `name` varchar(80) NOT NULL,
  `email` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(40) NOT NULL,
  `contact` varchar(40) NOT NULL,
  `address` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `country_head`
--

INSERT INTO `country_head` (`id`, `name`, `email`, `username`, `password`, `contact`, `address`) VALUES
(2, 'Zubair Fiaz', 'zubair@gmail.com', 'zubair123', '12345', '03008765678', 'XYZ');

-- --------------------------------------------------------

--
-- Table structure for table `covid_test_info`
--

CREATE TABLE `covid_test_info` (
  `id` int(11) NOT NULL,
  `technician_id` int(11) NOT NULL,
  `hospital_id` int(11) NOT NULL,
  `name` varchar(80) NOT NULL,
  `age` int(11) NOT NULL,
  `gender` varchar(80) NOT NULL,
  `cnic` varchar(30) NOT NULL,
  `contact` varchar(30) NOT NULL,
  `address` varchar(80) NOT NULL,
  `specimen` varchar(80) NOT NULL,
  `result` varchar(80) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `covid_test_info`
--

INSERT INTO `covid_test_info` (`id`, `technician_id`, `hospital_id`, `name`, `age`, `gender`, `cnic`, `contact`, `address`, `specimen`, `result`, `date`) VALUES
(3, 3, 3, 'Muhammad Asghar', 34, 'Male', '3824758214578', '0312546987', 'XYZ', 'Throat Infection', 'Positive', '2022-04-10'),
(4, 3, 3, 'Asghar Ali', 26, 'Male', '8784990736678798', '03008879890', 'SYZ', 'ABC', 'Positive', '2022-06-13'),
(5, 3, 0, 'Liaqat Abbas', 35, 'Male', '4897890932890', '09398892', 'address', 'XYZ', 'Positive', '2022-06-29');

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `id` int(11) NOT NULL,
  `name` varchar(80) NOT NULL,
  `email` varchar(80) NOT NULL,
  `username` varchar(80) NOT NULL,
  `password` varchar(80) NOT NULL,
  `contact` varchar(80) NOT NULL,
  `speciality` varchar(80) NOT NULL,
  `address` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`id`, `name`, `email`, `username`, `password`, `contact`, `speciality`, `address`) VALUES
(3, 'Muhammad Mansoor', 'm.mansoor@gmail.com', 'mansoor123', '12345', '03002154789', 'Skin Specialist', 'ABC'),
(6, 'Muhammad Zafar', 'zafar@gmail.com', 'zafar123', 'abcd1234', '030087877899', 'Sychologist', 'ABC');

-- --------------------------------------------------------

--
-- Table structure for table `doctor_work`
--

CREATE TABLE `doctor_work` (
  `id` int(11) NOT NULL,
  `doctor_id` int(11) NOT NULL,
  `hospital_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `doctor_work`
--

INSERT INTO `doctor_work` (`id`, `doctor_id`, `hospital_id`) VALUES
(1, 3, 2),
(2, 3, 3),
(4, 4, 2),
(5, 5, 3),
(6, 6, 3);

-- --------------------------------------------------------

--
-- Table structure for table `hospital`
--

CREATE TABLE `hospital` (
  `id` int(11) NOT NULL,
  `city_id` int(11) NOT NULL,
  `hospital_name` varchar(60) NOT NULL,
  `address` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hospital`
--

INSERT INTO `hospital` (`id`, `city_id`, `hospital_name`, `address`) VALUES
(2, 1, 'Shoukat Khanam Memorial Hospital Lahore', 'Shoukat Khanam Memorial Hospital 7A Block R-3 M-A. Johar Town Lahore'),
(3, 1, 'Fatima Jinnah Hospital Lahore', 'Ali Town ');

-- --------------------------------------------------------

--
-- Table structure for table `hospital_head`
--

CREATE TABLE `hospital_head` (
  `id` int(11) NOT NULL,
  `hospital_id` int(11) NOT NULL,
  `name` varchar(80) NOT NULL,
  `email` varchar(80) NOT NULL,
  `username` varchar(80) NOT NULL,
  `password` varchar(40) NOT NULL,
  `contact` varchar(30) NOT NULL,
  `address` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hospital_head`
--

INSERT INTO `hospital_head` (`id`, `hospital_id`, `name`, `email`, `username`, `password`, `contact`, `address`) VALUES
(1, 2, 'Kamran Ashraf', 'kamran.ashraf@gmail.com', 'kamranashraf01', 'asdf123', '03024578541', 'XYZ'),
(2, 3, 'Muhammad Naseem', 'naseem@gmail.com', 'naseem123', '12345', '03007876799', 'Some address');

-- --------------------------------------------------------

--
-- Table structure for table `patient_info`
--

CREATE TABLE `patient_info` (
  `id` int(11) NOT NULL,
  `hospital_id` int(11) NOT NULL,
  `name` varchar(80) NOT NULL,
  `age` int(11) NOT NULL,
  `gender` varchar(30) NOT NULL,
  `cnic` varchar(30) NOT NULL,
  `contact` varchar(30) NOT NULL,
  `address` varchar(80) NOT NULL,
  `date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patient_info`
--

INSERT INTO `patient_info` (`id`, `hospital_id`, `name`, `age`, `gender`, `cnic`, `contact`, `address`, `date`) VALUES
(6, 2, 'Muhammad Ali', 34, 'Male', '541124787211243', '03051245879', 'Some address', '2022-04-08'),
(8, 2, 'Abu Bakar', 23, 'Male', '8130289876787', '0300786568', 'XYZ', '2022-06-13'),
(9, 3, 'Bilal Ahmad', 34, 'Male', '12345678', '03088879898', 'ABC', '2022-06-29'),
(10, 2, 'Muhammad Noman', 24, 'Male', '37389579828', '8947927', 'ABC', '2022-06-29');

-- --------------------------------------------------------

--
-- Table structure for table `receptionist`
--

CREATE TABLE `receptionist` (
  `id` int(11) NOT NULL,
  `hospital_id` int(11) NOT NULL,
  `name` varchar(80) NOT NULL,
  `email` varchar(80) NOT NULL,
  `username` varchar(80) NOT NULL,
  `password` varchar(80) NOT NULL,
  `contact` varchar(80) NOT NULL,
  `address` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `receptionist`
--

INSERT INTO `receptionist` (`id`, `hospital_id`, `name`, `email`, `username`, `password`, `contact`, `address`) VALUES
(4, 2, 'Muhammad Baqir', 'muhammadbaqir@gmail.com', 'm.baqir123', '12345', '0302541254', 'Some address'),
(5, 2, 'Muhammad Umar', 'umar@gmail.com', 'umar123', 'asdf0000', '03216090876', 'XYZ'),
(6, 3, 'Shahid Awais', 'shahid@gmail.com', 'shahid12', '12345', '0304878987', 'XYZ');

-- --------------------------------------------------------

--
-- Table structure for table `technician`
--

CREATE TABLE `technician` (
  `id` int(11) NOT NULL,
  `name` varchar(80) NOT NULL,
  `email` varchar(80) NOT NULL,
  `username` varchar(80) NOT NULL,
  `password` varchar(80) NOT NULL,
  `contact` varchar(80) NOT NULL,
  `address` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `technician`
--

INSERT INTO `technician` (`id`, `name`, `email`, `username`, `password`, `contact`, `address`) VALUES
(3, 'Malik Aslam', 'malikaslam@gmail.com', 'malik.aslam001', 'asdf1234', '0302145785', 'XYZ'),
(4, 'Muhammad Shahid', 'shahid@gmail.com', 'm.shahid', '12356', '0308765681', 'Some address'),
(6, 'Muhammad Islam', 'islam@gmail.com', 'islam001', '00001111', '03008787988', 'ABC');

-- --------------------------------------------------------

--
-- Table structure for table `technician_work`
--

CREATE TABLE `technician_work` (
  `id` int(11) NOT NULL,
  `technician_id` int(11) NOT NULL,
  `hospital_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `technician_work`
--

INSERT INTO `technician_work` (`id`, `technician_id`, `hospital_id`) VALUES
(1, 3, 2),
(2, 3, 3),
(3, 4, 2),
(6, 6, 2),
(7, 6, 3);

-- --------------------------------------------------------

--
-- Table structure for table `treatment_info`
--

CREATE TABLE `treatment_info` (
  `id` int(11) NOT NULL,
  `doctor_id` int(11) NOT NULL,
  `hospital_id` int(11) NOT NULL,
  `name` varchar(80) NOT NULL,
  `age` int(11) NOT NULL,
  `gender` varchar(30) NOT NULL,
  `address` varchar(80) NOT NULL,
  `description` text NOT NULL,
  `date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `treatment_info`
--

INSERT INTO `treatment_info` (`id`, `doctor_id`, `hospital_id`, `name`, `age`, `gender`, `address`, `description`, `date`) VALUES
(1, 3, 2, 'Wajiha Sabir', 26, 'Female', 'ABC', 'This is the description of the prescription.', '2022-02-11'),
(2, 3, 3, 'Zulfiqar Baba', 34, 'Male', 'Some Address', 'This is the description of the presecription.', '2022-02-13'),
(3, 3, 3, 'Wajahat Ali', 27, 'Male', 'XYZ', 'Some description.', '2022-04-10'),
(4, 3, 3, 'Muhammad Naveed', 26, 'Male', 'Some address', 'some description.', '2022-06-13'),
(5, 3, 3, 'Naveed tariq', 26, 'Male', 'some address', 'this is the desc..', '2022-06-29');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admit_patient`
--
ALTER TABLE `admit_patient`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `city`
--
ALTER TABLE `city`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `city_head`
--
ALTER TABLE `city_head`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `country_head`
--
ALTER TABLE `country_head`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `covid_test_info`
--
ALTER TABLE `covid_test_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctor_work`
--
ALTER TABLE `doctor_work`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hospital`
--
ALTER TABLE `hospital`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hospital_head`
--
ALTER TABLE `hospital_head`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `patient_info`
--
ALTER TABLE `patient_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `receptionist`
--
ALTER TABLE `receptionist`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `technician`
--
ALTER TABLE `technician`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `technician_work`
--
ALTER TABLE `technician_work`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `treatment_info`
--
ALTER TABLE `treatment_info`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `admit_patient`
--
ALTER TABLE `admit_patient`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `city`
--
ALTER TABLE `city`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `city_head`
--
ALTER TABLE `city_head`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `country_head`
--
ALTER TABLE `country_head`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `covid_test_info`
--
ALTER TABLE `covid_test_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `doctor`
--
ALTER TABLE `doctor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `doctor_work`
--
ALTER TABLE `doctor_work`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `hospital`
--
ALTER TABLE `hospital`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `hospital_head`
--
ALTER TABLE `hospital_head`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `patient_info`
--
ALTER TABLE `patient_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `receptionist`
--
ALTER TABLE `receptionist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `technician`
--
ALTER TABLE `technician`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `technician_work`
--
ALTER TABLE `technician_work`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `treatment_info`
--
ALTER TABLE `treatment_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
